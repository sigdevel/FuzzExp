console.error(__filename);
console.error(module.paths.join('\n') + '\n');
