'use strict';
const punycode = require('punycode');
punycode.decode('x');
