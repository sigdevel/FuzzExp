promise_test(define_tests, 'setup - define tests');
