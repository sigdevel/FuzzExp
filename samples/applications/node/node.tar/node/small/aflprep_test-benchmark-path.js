'use strict';
runBenchmark('path', { NODEJS_BENCHMARK_ZERO_ALLOWED: 1 });
