'use strict';
console.log('42');
