'use strict';
class Class {
  constructor() {};
  method() {};
}
module.exports = {
  Class
};
