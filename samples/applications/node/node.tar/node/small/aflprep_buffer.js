'use strict';
function Buffer() {
}
Buffer.prototype.instanceMethod = function() {}
module.exports = {
  Buffer
};
