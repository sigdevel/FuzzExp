'use strict';
console.log({}.flatten.name);
