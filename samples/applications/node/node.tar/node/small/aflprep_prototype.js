'use strict';
function Class() {
}
Class.classMethod = function() {}
Class.prototype.instanceMethod = function() {}
module.exports = {
  Class
};
