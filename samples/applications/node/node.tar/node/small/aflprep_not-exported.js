'use strict';
module.exports = 'not-exported';
