'use strict';
console.trace('foo');
