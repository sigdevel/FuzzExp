'use strict';
require('path');
console.log('executed');
