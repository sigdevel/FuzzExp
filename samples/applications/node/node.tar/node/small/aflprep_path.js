exports.path_func = function() {
  return 'path_func';
};
