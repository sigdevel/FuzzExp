'use strict';
function foo() {
}
module.exports = {
  foo
};
