'use strict';
runBenchmark('policy', [
  'n=1',
]);
