'use strict';
runBenchmark('assert');
