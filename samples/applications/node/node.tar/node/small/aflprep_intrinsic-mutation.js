'use strict';
Object.defineProperty(
  Object.prototype,
  'flatten', {
    enumerable: false,
    value: function smoosh() {}
  }
);
