idl_test(
  ['console'],
);
