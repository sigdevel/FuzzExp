'use strict';
runBenchmark('streams', { NODEJS_BENCHMARK_ZERO_ALLOWED: 1 });
