'use strict';
Object.getOwnPropertyNames(Math).forEach((functionName) => {
    Math[functionName](-0.5);
  }
});
