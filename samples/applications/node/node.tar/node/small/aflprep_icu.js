const React = {
  createElement: () => {
    "あ 🐕 🐕", function (e) {
      throw e;
    }(Error("an error"));
  }
};
  src: "avatar.png",
  className: "profile"
