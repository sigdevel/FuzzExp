'use strict';
tmpdir.refresh();
runBenchmark('fs', { NODEJS_BENCHMARK_ZERO_ALLOWED: 1 });
