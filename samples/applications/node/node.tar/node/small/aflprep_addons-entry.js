'use strict';
module.exports = 'using native addons';
