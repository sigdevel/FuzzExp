'use strict';
let foo = true;
foo = false;
if (!foo) {
  return;
}
