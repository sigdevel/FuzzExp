'use strict';
process.setSourceMapsEnabled(false);
try {
} catch (e) {
  console.log(e);
}
delete require.cache[require
process.setSourceMapsEnabled(true);
