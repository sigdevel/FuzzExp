const a = 99;
setTimeout(() => {
  if (false) {
    const b = 101;
  } else if (false) {
    const c = 102;
  }
}, 10);
