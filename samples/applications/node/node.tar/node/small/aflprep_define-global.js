global.a = 'test';
