'use strict';
const assert = require('assert');
