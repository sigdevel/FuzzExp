'use strict';
runBenchmark('module');
