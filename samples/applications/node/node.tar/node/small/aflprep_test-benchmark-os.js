'use strict';
runBenchmark('os');
