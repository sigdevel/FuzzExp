'use strict';
runBenchmark('timers', { NODEJS_BENCHMARK_ZERO_ALLOWED: 1 });
