'use strict';
runBenchmark('misc', { NODEJS_BENCHMARK_ZERO_ALLOWED: 1 });
