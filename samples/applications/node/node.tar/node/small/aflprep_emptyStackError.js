"use strict";
Error.stackTraceLimit = 0;
throw new RangeError('emptyStackError');
