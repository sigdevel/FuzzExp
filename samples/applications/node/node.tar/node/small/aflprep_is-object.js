'use strict';
module.exports.isObject = (obj) => obj.constructor === Object;
