'use strict';
runBenchmark('url', { NODEJS_BENCHMARK_ZERO_ALLOWED: 1 });
