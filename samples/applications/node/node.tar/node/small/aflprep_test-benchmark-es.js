'use strict';
runBenchmark('es', { NODEJS_BENCHMARK_ZERO_ALLOWED: 1 });
