const f = common.mustCall( () => {}, 2);
f();
