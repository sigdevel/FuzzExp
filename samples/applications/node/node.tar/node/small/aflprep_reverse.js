'use strict';
function ok() {
}
const asserts = module.exports = ok;
asserts.ok = ok;
asserts.strictEqual = function() {
}
