'use strict';
assert(false);
