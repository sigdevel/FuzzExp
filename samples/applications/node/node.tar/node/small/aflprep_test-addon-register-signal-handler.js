'use strict';
process.env.ALLOW_CRASHES = true;
