const f = common.mustCallAtLeast(() => {}, 2);
f();
