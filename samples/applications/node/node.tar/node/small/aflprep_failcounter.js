new Countdown(2, () => {});
