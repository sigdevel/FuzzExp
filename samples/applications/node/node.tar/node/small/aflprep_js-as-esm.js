export const namedExport = 'named-export';
