'use strict';
module.exports = 'not using native addons';
