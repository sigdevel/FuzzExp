'use strict';
runBenchmark('zlib', { NODEJS_BENCHMARK_ZERO_ALLOWED: 1 });
