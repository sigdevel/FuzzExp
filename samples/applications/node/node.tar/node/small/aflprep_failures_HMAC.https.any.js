run_test(["HMAC"]);
