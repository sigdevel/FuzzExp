'use strict';
runBenchmark('dgram');
