module.exports = 'self-cjs';
