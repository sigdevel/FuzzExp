'use strict';
runner.runJsTests();
