'use strict';
runBenchmark('cluster');
