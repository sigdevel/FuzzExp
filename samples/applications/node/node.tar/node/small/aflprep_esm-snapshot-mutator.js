'use strict';
require.cache[shouldSnapshotFilePath].exports++;
