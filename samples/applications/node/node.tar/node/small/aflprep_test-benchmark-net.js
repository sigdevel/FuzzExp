'use strict';
runBenchmark('net', { NODEJS_BENCHMARK_ZERO_ALLOWED: 1 });
