 * comments dropped by uglify.
