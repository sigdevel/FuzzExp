'use strict';
runBenchmark('vm', { NODEJS_BENCHMARK_ZERO_ALLOWED: 1 });
