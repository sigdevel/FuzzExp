onmessage = evt => postMessage(evt.data, [evt.data]);
