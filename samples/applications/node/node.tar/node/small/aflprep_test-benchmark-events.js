'use strict';
runBenchmark('events', { NODEJS_BENCHMARK_ZERO_ALLOWED: 1 });
