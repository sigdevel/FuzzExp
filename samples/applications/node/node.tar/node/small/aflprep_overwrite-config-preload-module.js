'use strict'
common.skipIfInspectorDisabled();
process.config = {};
