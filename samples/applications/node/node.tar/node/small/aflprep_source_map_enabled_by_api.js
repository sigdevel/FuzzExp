'use strict';
process.setSourceMapsEnabled(true);
try {
} catch (e) {
  console.log(e);
}
delete require.cache[require
process.setSourceMapsEnabled(false);
