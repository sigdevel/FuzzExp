'use strict';
runBenchmark('child_process', { NODEJS_BENCHMARK_ZERO_ALLOWED: 1 });
