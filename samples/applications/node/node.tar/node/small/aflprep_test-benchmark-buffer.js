'use strict';
runBenchmark('buffers', { NODEJS_BENCHMARK_ZERO_ALLOWED: 1 });
