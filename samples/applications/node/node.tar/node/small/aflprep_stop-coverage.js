'use strict';
const v8 = require('v8');
v8.stopCoverage();
