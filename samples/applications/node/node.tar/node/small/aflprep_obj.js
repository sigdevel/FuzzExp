'use strict';
module.exports = { obj: 'module' }
