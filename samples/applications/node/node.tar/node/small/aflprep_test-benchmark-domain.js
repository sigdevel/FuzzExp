'use strict';
runBenchmark('domain');
