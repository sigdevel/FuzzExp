'use strict';
runBenchmark('string_decoder');
