'use strict';
try {
} catch (err) {
  setTimeout(() => {
    console.info(err);
  }, 10);
}
