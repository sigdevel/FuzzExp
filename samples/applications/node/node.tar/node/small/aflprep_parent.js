'use strict';
require('crypto').DEFAULT_ENCODING = process.env.DEFAULT_ENCODING;
