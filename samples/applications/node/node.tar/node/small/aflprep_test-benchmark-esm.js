'use strict';
runBenchmark('esm', { NODEJS_BENCHMARK_ZERO_ALLOWED: 1 });
