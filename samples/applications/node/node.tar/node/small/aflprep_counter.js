global.counter = global.counter || 0;
global.counter++;