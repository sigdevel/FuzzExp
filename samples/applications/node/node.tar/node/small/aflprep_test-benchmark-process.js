'use strict';
runBenchmark('process', { NODEJS_BENCHMARK_ZERO_ALLOWED: 1 });
