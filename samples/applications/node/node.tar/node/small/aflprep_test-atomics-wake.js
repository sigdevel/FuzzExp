'use strict';
const assert = require('assert');
assert.strictEqual(Atomics.wake, undefined);
