'use strict';
process.on('warning', common.mustNotCall());
Buffer.of(0, 1);
