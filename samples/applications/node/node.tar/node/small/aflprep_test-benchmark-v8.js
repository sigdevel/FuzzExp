'use strict';
runBenchmark('v8', { NODEJS_BENCHMARK_ZERO_ALLOWED: 1 });
