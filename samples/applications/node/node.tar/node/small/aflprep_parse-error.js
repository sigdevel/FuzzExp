console.log('require fails on next line');
